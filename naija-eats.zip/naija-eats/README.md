# Naija Eats — Nigerian Food Delivery App

An MVP food delivery platform for Nigeria: customers browse restaurants and order,
restaurant owners register their business and pay an affordable onboarding fee via
**Paystack**, and once approved they get a dashboard to manage incoming orders.

- **Mobile app**: Expo (React Native) — runs on iPhone and Android from one codebase.
- **Backend**: Node.js/Express + PostgreSQL, with Paystack for the registration fee.

## Project structure

```
naija-eats/
  backend/     Express API + Postgres schema + Paystack integration
  mobile/      Expo app (customer + restaurant-owner flows)
```

## 1. Backend setup

```bash
cd backend
npm install
cp .env.example .env
```

Edit `.env`:
- `DATABASE_URL` — your Postgres connection string (a free tier on Supabase,
  Railway, or Render works well for Nigeria-based hosting/latency).
- `JWT_SECRET` — any long random string.
- `PAYSTACK_SECRET_KEY` / `PAYSTACK_PUBLIC_KEY` — from your
  [Paystack dashboard](https://dashboard.paystack.com/#/settings/developer)
  (use the `sk_test_...` / `pk_test_...` keys while developing).
- `RESTAURANT_REGISTRATION_FEE_KOBO` — the fee, in kobo. `1000000` = ₦10,000.
  Set this to whatever "affordable" means for your market.
- `APP_BASE_URL` — must be a URL Paystack can redirect to. Use a tunnel
  (e.g. `ngrok http 4000`) while testing on a phone.

Create the database and load the schema:

```bash
createdb naija_eats                        # or create it in your hosting dashboard
psql $DATABASE_URL -f src/migrations/schema.sql
```

Run it:

```bash
npm run dev      # nodemon, auto-restarts
# or
npm start
```

Check it's alive: `curl http://localhost:4000/health` → `{"status":"ok"}`

### Manually approving a restaurant

There's no admin UI in this MVP — approve a paid restaurant directly:

```sql
-- after registration_status is 'paid'
UPDATE restaurants SET registration_status = 'approved', is_active = true WHERE id = '<restaurant-id>';
```

Or call `PATCH /api/restaurants/:id/approve` as a user with `role = 'admin'`
(create one by inserting a row into `users` with `role='admin'`, or promoting
an existing user).

## 2. Mobile app setup

```bash
cd mobile
npm install
```

Open `src/api/client.js` and set `API_BASE_URL` to your backend:
- iOS Simulator: `http://localhost:4000/api` works.
- Android Emulator: use `http://10.0.2.2:4000/api`.
- Physical phone (Expo Go): use your computer's LAN IP, e.g. `http://192.168.1.50:4000/api`,
  and make sure your phone and computer are on the same Wi-Fi.
- Paystack's checkout redirect (`callback_url`) needs a URL reachable from the
  internet even during development — use `ngrok http 4000` and put the ngrok
  URL in the backend's `APP_BASE_URL`.

Run it:

```bash
npx expo start
```

Scan the QR code with **Expo Go** (iOS or Android) to run it on your phone, or
press `i` / `a` for a simulator/emulator.

## How the restaurant registration + fee flow works

1. Owner signs up choosing **"Register my restaurant"** → `role: restaurant_owner`.
2. `RegisterScreen` collects business details → `POST /api/restaurants/register`
   creates a row with `registration_status = 'pending_payment'`.
3. `RegisterPaymentScreen` calls `POST /api/payments/registration/initiate`,
   which opens a Paystack transaction and returns a hosted checkout URL,
   shown in an in-app WebView.
4. After the owner pays, Paystack redirects to the backend's callback URL;
   the app intercepts that navigation and calls
   `GET /api/payments/registration/verify/:reference` to confirm payment
   server-side (a webhook handler is also included as the more reliable path
   for production — configure it in the Paystack dashboard).
5. Restaurant flips to `registration_status = 'paid'`, then an admin approves
   it (`is_active = true`), after which it appears in customer search and the
   owner can add menu items and receive orders.

## What's deliberately left out of this MVP (next steps)

- Admin web dashboard (approvals are done via SQL/API call above)
- Rider/courier app and live order tracking on a map
- In-app payment for customer orders (currently pay-on-delivery; wire it up
  the same way as the registration fee — Paystack transaction + verify)
- Push notifications, image uploads for menu items/logos, ratings & reviews
- Automated tests and CI

## Nigeria-specific notes

- All money is handled in **kobo** end-to-end (Paystack's native unit) to
  avoid floating-point rounding errors; the UI formats it as Naira.
- Phone numbers are stored as entered — add normalization (e.g. `080…` →
  `+234…`) before production if you plan to send SMS.
