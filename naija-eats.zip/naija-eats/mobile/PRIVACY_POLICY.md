# Naija Eats — Privacy Policy

_Last updated: [DATE]_

This policy must be hosted at a public URL before submission — App Store Connect
requires a live link, not a file. Easiest option: paste this into a new page in
Google Docs → "Publish to web", or into a simple page on your own site/GitHub Pages.

## Information We Collect

- **Account information**: full name, email address, phone number (collected at signup).
- **Restaurant information** (restaurant owners only): business name, address,
  phone number, cuisine type, and menu content you submit.
- **Order information**: delivery address and order contents, tied to your account.
- **Payment information**: registration fees are processed by **Paystack**.
  We do not receive or store your card number — Paystack handles payment
  details directly under its own privacy policy
  (https://paystack.com/privacy).

## How We Use Information

- To create and manage your account.
- To connect customers with restaurants and process orders.
- To process restaurant registration fee payments via Paystack.
- To communicate with you about your orders or restaurant listing.

## Information Sharing

- Restaurant owners see the delivery address and order contents for orders
  placed at their restaurant.
- We share payment details with Paystack solely to process transactions.
- We do not sell personal information to third parties.

## Data Retention

Account and order data is retained as long as your account is active. You may
request deletion of your account and associated data by contacting
[SUPPORT EMAIL].

## Children's Privacy

Naija Eats is not directed at children under 13, and we do not knowingly
collect information from them.

## Contact

Questions about this policy: [SUPPORT EMAIL]

---
**Before you publish this:** fill in the [DATE] and [SUPPORT EMAIL] placeholders,
and update it if you add features (e.g. push notifications, location tracking,
analytics SDKs) that collect additional data — Apple checks that the policy
matches what the app actually does.
