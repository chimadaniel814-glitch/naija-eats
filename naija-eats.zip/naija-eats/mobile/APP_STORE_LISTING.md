# App Store Listing — Draft Copy

Fill in the bracketed parts, then paste into App Store Connect → App Information / Version Information.

## App Name (30 char max)
Naija Eats

## Subtitle (30 char max)
Food delivery, made in Nigeria

## Promotional Text (170 char max, editable without a new build)
Order from restaurants near you, or register your restaurant to start
receiving orders. Built for Nigeria.

## Description (4000 char max)
Naija Eats connects hungry customers with restaurants across Nigeria — starting
in [YOUR LAUNCH CITY, e.g. Ibadan and Lagos].

FOR CUSTOMERS
- Browse restaurants near you by city and cuisine
- Order directly from the menu
- Track your order status in real time

FOR RESTAURANT OWNERS
- Register your restaurant in minutes
- Pay a one-time, affordable registration fee securely via Paystack
- Manage incoming orders from a simple dashboard once approved

Naija Eats is built for the way Nigerians order food — simple, fast, and
affordable for restaurants of any size to join.

## Keywords (100 char max, comma-separated, no spaces after commas)
food,delivery,nigeria,restaurant,order,lagos,ibadan,naija,eat,takeout

## Support URL
[e.g. https://yourdomain.com/support or a page with your support email]

## Marketing URL (optional)
[your website, if you have one]

## Privacy Policy URL
[public URL hosting PRIVACY_POLICY.md — see that file's note on how to publish it]

## Category
Primary: Food & Drink
Secondary: Business (optional, since it also serves restaurant owners)

## Age Rating
Likely 4+ — answer Apple's age rating questionnaire based on actual app content
(no user-generated media, no gambling, etc.)

## App Review Notes (paste into "Notes" for the reviewer)
This app has two account types, selected at signup:
1. Customer — browse restaurants and place orders.
2. Restaurant owner — register a restaurant (includes a one-time registration
   fee paid via Paystack, a licensed Nigerian payment processor, for the
   real-world service of restaurant onboarding — not digital content).

Demo accounts for review:
- Customer: [email] / [password]
- Restaurant owner: [email] / [password]
  (Note: to see the full restaurant-owner flow including the paid dashboard,
  use a restaurant that has already been approved — provide one pre-seeded,
  since Paystack test-mode payments may not be completable by the reviewer.)

## Screenshots needed (per device size Apple requires, e.g. 6.7" and 6.5" iPhone)
1. Restaurant list / home screen
2. Restaurant menu screen
3. Cart / checkout
4. Restaurant registration form
5. Restaurant dashboard with an order

Capture these from a simulator or device once the app is pointed at your
real (not localhost) backend, using `npx expo start` and pressing the
appropriate simulator, or from a physical device build.
