import React, { createContext, useContext, useState, useMemo } from 'react';

const CartContext = createContext(null);

export function CartProvider({ children }) {
  const [restaurantId, setRestaurantId] = useState(null);
  const [items, setItems] = useState([]); // { menuItemId, name, priceKobo, quantity }

  function addItem(restaurant, menuItem) {
    // Cart is single-restaurant: switching restaurants clears the cart
    if (restaurantId && restaurantId !== restaurant.id) {
      setItems([]);
    }
    setRestaurantId(restaurant.id);
    setItems((prev) => {
      const existing = prev.find((i) => i.menuItemId === menuItem.id);
      if (existing) {
        return prev.map((i) =>
          i.menuItemId === menuItem.id ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      return [...prev, { menuItemId: menuItem.id, name: menuItem.name, priceKobo: menuItem.price_kobo, quantity: 1 }];
    });
  }

  function updateQuantity(menuItemId, quantity) {
    if (quantity <= 0) {
      setItems((prev) => prev.filter((i) => i.menuItemId !== menuItemId));
      return;
    }
    setItems((prev) => prev.map((i) => (i.menuItemId === menuItemId ? { ...i, quantity } : i)));
  }

  function clearCart() {
    setItems([]);
    setRestaurantId(null);
  }

  const subtotalKobo = useMemo(
    () => items.reduce((sum, i) => sum + i.priceKobo * i.quantity, 0),
    [items]
  );

  return (
    <CartContext.Provider value={{ restaurantId, items, addItem, updateQuantity, clearCart, subtotalKobo }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  return useContext(CartContext);
}
