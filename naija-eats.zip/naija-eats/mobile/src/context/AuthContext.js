import React, { createContext, useContext, useState, useEffect } from 'react';
import * as SecureStore from 'expo-secure-store';
import client, { saveToken, clearToken } from '../api/client';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const token = await SecureStore.getItemAsync('authToken');
      const savedUser = await SecureStore.getItemAsync('authUser');
      if (token && savedUser) setUser(JSON.parse(savedUser));
      setLoading(false);
    })();
  }, []);

  async function login(email, password) {
    const { data } = await client.post('/auth/login', { email, password });
    await saveToken(data.token);
    await SecureStore.setItemAsync('authUser', JSON.stringify(data.user));
    setUser(data.user);
    return data.user;
  }

  async function signup(fullName, email, phone, password, role) {
    const { data } = await client.post('/auth/signup', { fullName, email, phone, password, role });
    await saveToken(data.token);
    await SecureStore.setItemAsync('authUser', JSON.stringify(data.user));
    setUser(data.user);
    return data.user;
  }

  async function logout() {
    await clearToken();
    await SecureStore.deleteItemAsync('authUser');
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
