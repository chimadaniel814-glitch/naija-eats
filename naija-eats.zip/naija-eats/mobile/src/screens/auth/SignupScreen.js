import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, ScrollView } from 'react-native';
import { useAuth } from '../../context/AuthContext';

export default function SignupScreen({ navigation }) {
  const { signup } = useAuth();
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('customer');
  const [loading, setLoading] = useState(false);

  async function handleSignup() {
    if (!fullName || !email || !phone || !password) {
      return Alert.alert('Missing info', 'Please fill in every field');
    }
    setLoading(true);
    try {
      await signup(fullName, email, phone, password, role);
    } catch (err) {
      Alert.alert('Signup failed', err.response?.data?.error || 'Something went wrong');
    } finally {
      setLoading(false);
    }
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Create Account</Text>

      <TextInput style={styles.input} placeholder="Full name" value={fullName} onChangeText={setFullName} />
      <TextInput
        style={styles.input}
        placeholder="Email"
        autoCapitalize="none"
        keyboardType="email-address"
        value={email}
        onChangeText={setEmail}
      />
      <TextInput
        style={styles.input}
        placeholder="Phone (e.g. 08012345678)"
        keyboardType="phone-pad"
        value={phone}
        onChangeText={setPhone}
      />
      <TextInput style={styles.input} placeholder="Password" secureTextEntry value={password} onChangeText={setPassword} />

      <Text style={styles.label}>I want to:</Text>
      <View style={styles.roleRow}>
        <TouchableOpacity
          style={[styles.roleButton, role === 'customer' && styles.roleButtonActive]}
          onPress={() => setRole('customer')}
        >
          <Text style={[styles.roleText, role === 'customer' && styles.roleTextActive]}>Order food</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.roleButton, role === 'restaurant_owner' && styles.roleButtonActive]}
          onPress={() => setRole('restaurant_owner')}
        >
          <Text style={[styles.roleText, role === 'restaurant_owner' && styles.roleTextActive]}>
            Register my restaurant
          </Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.button} onPress={handleSignup} disabled={loading}>
        <Text style={styles.buttonText}>{loading ? 'Creating…' : 'Create Account'}</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate('Login')}>
        <Text style={styles.link}>Already have an account? Log in</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flexGrow: 1, padding: 24, justifyContent: 'center', backgroundColor: '#fff' },
  title: { fontSize: 26, fontWeight: '800', color: '#0B8457', textAlign: 'center', marginBottom: 24 },
  input: { borderWidth: 1, borderColor: '#ddd', borderRadius: 10, padding: 14, marginBottom: 12, fontSize: 16 },
  label: { fontSize: 14, color: '#333', marginBottom: 8, marginTop: 4, fontWeight: '600' },
  roleRow: { flexDirection: 'row', gap: 10, marginBottom: 20 },
  roleButton: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#0B8457',
    borderRadius: 10,
    padding: 12,
    alignItems: 'center',
  },
  roleButtonActive: { backgroundColor: '#0B8457' },
  roleText: { color: '#0B8457', fontWeight: '600', fontSize: 13, textAlign: 'center' },
  roleTextActive: { color: '#fff' },
  button: { backgroundColor: '#0B8457', borderRadius: 10, padding: 16, alignItems: 'center' },
  buttonText: { color: '#fff', fontWeight: '700', fontSize: 16 },
  link: { color: '#0B8457', textAlign: 'center', marginTop: 20, fontSize: 14 },
});
