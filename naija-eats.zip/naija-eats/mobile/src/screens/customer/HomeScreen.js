import React, { useEffect, useState, useCallback } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, TextInput, RefreshControl } from 'react-native';
import client from '../../api/client';

export default function HomeScreen({ navigation }) {
  const [restaurants, setRestaurants] = useState([]);
  const [city, setCity] = useState('');
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await client.get('/restaurants', { params: city ? { city } : {} });
      setRestaurants(data);
    } catch (err) {
      console.warn('Failed to load restaurants', err.message);
    } finally {
      setLoading(false);
    }
  }, [city]);

  useEffect(() => {
    load();
  }, [load]);

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Find food near you</Text>
      <TextInput
        style={styles.search}
        placeholder="Filter by city (e.g. Ibadan, Lagos)"
        value={city}
        onChangeText={setCity}
        onSubmitEditing={load}
      />
      <FlatList
        data={restaurants}
        keyExtractor={(item) => item.id}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={load} />}
        ListEmptyComponent={
          !loading && <Text style={styles.empty}>No restaurants found yet. Check back soon!</Text>
        }
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('Restaurant', { restaurant: item })}>
            <View style={styles.cardLogo}>
              <Text style={styles.cardLogoText}>{item.name.charAt(0)}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardTitle}>{item.name}</Text>
              <Text style={styles.cardSubtitle}>{item.cuisine_type || 'Nigerian cuisine'} · {item.city}</Text>
            </View>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', paddingTop: 16, paddingHorizontal: 16 },
  header: { fontSize: 24, fontWeight: '800', marginBottom: 12 },
  search: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 10,
    padding: 12,
    marginBottom: 16,
  },
  empty: { textAlign: 'center', color: '#888', marginTop: 40 },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 14,
    borderRadius: 12,
    backgroundColor: '#F6F6F6',
    marginBottom: 12,
  },
  cardLogo: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#0B8457',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  cardLogoText: { color: '#fff', fontWeight: '800', fontSize: 18 },
  cardTitle: { fontSize: 16, fontWeight: '700' },
  cardSubtitle: { fontSize: 13, color: '#777', marginTop: 2 },
});
