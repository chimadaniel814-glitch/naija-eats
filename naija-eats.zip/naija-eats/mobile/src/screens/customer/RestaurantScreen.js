import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import client from '../../api/client';
import { useCart } from '../../context/CartContext';
import { formatNaira } from '../../utils/format';

export default function RestaurantScreen({ route, navigation }) {
  const { restaurant } = route.params;
  const [menu, setMenu] = useState([]);
  const { addItem, items } = useCart();

  useEffect(() => {
    client.get(`/menu/restaurant/${restaurant.id}`).then(({ data }) => setMenu(data));
  }, [restaurant.id]);

  const cartCount = items.reduce((sum, i) => sum + i.quantity, 0);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{restaurant.name}</Text>
      <Text style={styles.subtitle}>{restaurant.description || `${restaurant.cuisine_type} · ${restaurant.address}`}</Text>

      <FlatList
        data={menu}
        keyExtractor={(item) => item.id}
        ListEmptyComponent={<Text style={styles.empty}>This restaurant hasn't added menu items yet.</Text>}
        renderItem={({ item }) => (
          <View style={styles.item}>
            <View style={{ flex: 1 }}>
              <Text style={styles.itemName}>{item.name}</Text>
              {!!item.description && <Text style={styles.itemDesc}>{item.description}</Text>}
              <Text style={styles.itemPrice}>{formatNaira(item.price_kobo)}</Text>
            </View>
            <TouchableOpacity style={styles.addButton} onPress={() => addItem(restaurant, item)}>
              <Text style={styles.addButtonText}>Add</Text>
            </TouchableOpacity>
          </View>
        )}
      />

      {cartCount > 0 && (
        <TouchableOpacity style={styles.cartBar} onPress={() => navigation.navigate('Cart')}>
          <Text style={styles.cartBarText}>View cart ({cartCount})</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', padding: 16 },
  title: { fontSize: 22, fontWeight: '800' },
  subtitle: { fontSize: 13, color: '#777', marginBottom: 16, marginTop: 4 },
  empty: { textAlign: 'center', color: '#888', marginTop: 40 },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  itemName: { fontSize: 16, fontWeight: '700' },
  itemDesc: { fontSize: 13, color: '#777', marginTop: 2 },
  itemPrice: { fontSize: 14, color: '#0B8457', fontWeight: '700', marginTop: 4 },
  addButton: { backgroundColor: '#0B8457', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 8 },
  addButtonText: { color: '#fff', fontWeight: '700' },
  cartBar: {
    position: 'absolute',
    bottom: 20,
    left: 16,
    right: 16,
    backgroundColor: '#0B8457',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  cartBarText: { color: '#fff', fontWeight: '700', fontSize: 16 },
});
