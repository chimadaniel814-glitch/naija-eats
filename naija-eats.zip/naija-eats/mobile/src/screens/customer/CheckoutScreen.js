import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import client from '../../api/client';
import { useCart } from '../../context/CartContext';
import { formatNaira } from '../../utils/format';

const DELIVERY_FEE_KOBO = 80000; // ₦800 flat fee — swap for distance-based pricing later

export default function CheckoutScreen({ navigation }) {
  const { restaurantId, items, subtotalKobo, clearCart } = useCart();
  const [address, setAddress] = useState('');
  const [placing, setPlacing] = useState(false);

  async function placeOrder() {
    if (!address) return Alert.alert('Missing address', 'Enter a delivery address');
    setPlacing(true);
    try {
      const { data } = await client.post('/orders', {
        restaurantId,
        deliveryAddress: address,
        deliveryFeeKobo: DELIVERY_FEE_KOBO,
        items: items.map((i) => ({ menuItemId: i.menuItemId, quantity: i.quantity })),
      });
      clearCart();
      Alert.alert('Order placed!', `Your order at total ${formatNaira(data.total_kobo)} has been sent to the restaurant.`);
      navigation.navigate('Orders');
    } catch (err) {
      Alert.alert('Could not place order', err.response?.data?.error || 'Try again');
    } finally {
      setPlacing(false);
    }
  }

  const total = subtotalKobo + DELIVERY_FEE_KOBO;

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Delivery address</Text>
      <TextInput
        style={styles.input}
        placeholder="e.g. 12 Ring Road, Ibadan"
        value={address}
        onChangeText={setAddress}
        multiline
      />

      <View style={styles.summary}>
        <View style={styles.row}>
          <Text style={styles.rowLabel}>Subtotal</Text>
          <Text style={styles.rowValue}>{formatNaira(subtotalKobo)}</Text>
        </View>
        <View style={styles.row}>
          <Text style={styles.rowLabel}>Delivery fee</Text>
          <Text style={styles.rowValue}>{formatNaira(DELIVERY_FEE_KOBO)}</Text>
        </View>
        <View style={[styles.row, { marginTop: 8 }]}>
          <Text style={styles.totalLabel}>Total</Text>
          <Text style={styles.totalValue}>{formatNaira(total)}</Text>
        </View>
      </View>

      <TouchableOpacity style={styles.button} onPress={placeOrder} disabled={placing}>
        <Text style={styles.buttonText}>{placing ? 'Placing order…' : 'Place Order (Pay on Delivery)'}</Text>
      </TouchableOpacity>
      <Text style={styles.note}>
        Card payment at checkout can be added the same way restaurant registration fees are handled — via Paystack.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', padding: 16 },
  label: { fontSize: 14, fontWeight: '700', marginBottom: 8 },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 10,
    padding: 14,
    minHeight: 60,
    textAlignVertical: 'top',
    marginBottom: 20,
  },
  summary: { backgroundColor: '#F6F6F6', borderRadius: 12, padding: 16, marginBottom: 20 },
  row: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  rowLabel: { color: '#666' },
  rowValue: { color: '#333', fontWeight: '600' },
  totalLabel: { fontWeight: '800', fontSize: 16 },
  totalValue: { fontWeight: '800', fontSize: 16, color: '#0B8457' },
  button: { backgroundColor: '#0B8457', borderRadius: 10, padding: 16, alignItems: 'center' },
  buttonText: { color: '#fff', fontWeight: '700', fontSize: 16 },
  note: { fontSize: 12, color: '#999', marginTop: 12, textAlign: 'center' },
});
