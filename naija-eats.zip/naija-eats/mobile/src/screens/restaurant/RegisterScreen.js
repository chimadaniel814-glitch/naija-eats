import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, ScrollView } from 'react-native';
import client from '../../api/client';

export default function RegisterScreen({ navigation }) {
  const [form, setForm] = useState({
    name: '',
    description: '',
    cuisineType: '',
    address: '',
    city: '',
    state: '',
    phone: '',
  });
  const [submitting, setSubmitting] = useState(false);

  function set(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function submit() {
    const { name, address, city, state, phone } = form;
    if (!name || !address || !city || !state || !phone) {
      return Alert.alert('Missing info', 'Please fill in name, address, city, state and phone');
    }
    setSubmitting(true);
    try {
      const { data: restaurant } = await client.post('/restaurants/register', form);
      // Next: send them to pay the affordable registration fee via Paystack
      navigation.navigate('RegisterPayment', { restaurant });
    } catch (err) {
      Alert.alert('Could not register', err.response?.data?.error || 'Try again');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Register Your Restaurant</Text>
      <Text style={styles.subtitle}>
        Fill in your business details. There's a one-time, affordable registration fee to get listed.
      </Text>

      <TextInput style={styles.input} placeholder="Restaurant name" value={form.name} onChangeText={(v) => set('name', v)} />
      <TextInput
        style={styles.input}
        placeholder="Short description"
        value={form.description}
        onChangeText={(v) => set('description', v)}
      />
      <TextInput
        style={styles.input}
        placeholder="Cuisine type (e.g. Local dishes, Continental)"
        value={form.cuisineType}
        onChangeText={(v) => set('cuisineType', v)}
      />
      <TextInput style={styles.input} placeholder="Street address" value={form.address} onChangeText={(v) => set('address', v)} />
      <TextInput style={styles.input} placeholder="City (e.g. Ibadan)" value={form.city} onChangeText={(v) => set('city', v)} />
      <TextInput style={styles.input} placeholder="State (e.g. Oyo)" value={form.state} onChangeText={(v) => set('state', v)} />
      <TextInput
        style={styles.input}
        placeholder="Business phone"
        keyboardType="phone-pad"
        value={form.phone}
        onChangeText={(v) => set('phone', v)}
      />

      <TouchableOpacity style={styles.button} onPress={submit} disabled={submitting}>
        <Text style={styles.buttonText}>{submitting ? 'Submitting…' : 'Continue to Payment'}</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flexGrow: 1, padding: 20, backgroundColor: '#fff' },
  title: { fontSize: 22, fontWeight: '800', marginBottom: 6 },
  subtitle: { fontSize: 13, color: '#777', marginBottom: 20 },
  input: { borderWidth: 1, borderColor: '#ddd', borderRadius: 10, padding: 14, marginBottom: 12, fontSize: 16 },
  button: { backgroundColor: '#0B8457', borderRadius: 10, padding: 16, alignItems: 'center', marginTop: 8 },
  buttonText: { color: '#fff', fontWeight: '700', fontSize: 16 },
});
