import React, { useCallback, useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, RefreshControl, Alert } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import client from '../../api/client';
import { formatNaira } from '../../utils/format';

const NEXT_STATUS = {
  pending: 'accepted',
  accepted: 'preparing',
  preparing: 'out_for_delivery',
  out_for_delivery: 'delivered',
};

const STATUS_LABEL = {
  pending: 'New',
  accepted: 'Accepted',
  preparing: 'Preparing',
  out_for_delivery: 'Out for delivery',
  delivered: 'Delivered',
  cancelled: 'Cancelled',
};

export default function DashboardScreen({ route }) {
  const { restaurant } = route.params;
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await client.get(`/orders/restaurant/${restaurant.id}`);
      setOrders(data);
    } catch (err) {
      console.warn(err.message);
    } finally {
      setLoading(false);
    }
  }, [restaurant.id]);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  async function advance(order) {
    const next = NEXT_STATUS[order.status];
    if (!next) return;
    try {
      await client.patch(`/orders/${order.id}/status`, { status: next });
      load();
    } catch (err) {
      Alert.alert('Could not update order', err.response?.data?.error || 'Try again');
    }
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{restaurant.name} — Orders</Text>
      <FlatList
        data={orders}
        keyExtractor={(item) => item.id}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={load} />}
        ListEmptyComponent={!loading && <Text style={styles.empty}>No orders yet</Text>}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <View style={{ flex: 1 }}>
              <Text style={styles.total}>{formatNaira(item.total_kobo)}</Text>
              <Text style={styles.address}>{item.delivery_address}</Text>
              <Text style={styles.status}>{STATUS_LABEL[item.status]}</Text>
            </View>
            {NEXT_STATUS[item.status] && (
              <TouchableOpacity style={styles.advanceButton} onPress={() => advance(item)}>
                <Text style={styles.advanceText}>Mark {STATUS_LABEL[NEXT_STATUS[item.status]]}</Text>
              </TouchableOpacity>
            )}
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', padding: 16 },
  title: { fontSize: 20, fontWeight: '800', marginBottom: 16 },
  empty: { textAlign: 'center', color: '#888', marginTop: 40 },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F6F6F6',
    borderRadius: 12,
    padding: 14,
    marginBottom: 10,
  },
  total: { fontSize: 16, fontWeight: '800' },
  address: { fontSize: 13, color: '#777', marginTop: 4 },
  status: { fontSize: 13, color: '#0B8457', fontWeight: '700', marginTop: 4 },
  advanceButton: { backgroundColor: '#0B8457', borderRadius: 8, paddingHorizontal: 12, paddingVertical: 8 },
  advanceText: { color: '#fff', fontWeight: '700', fontSize: 12 },
});
