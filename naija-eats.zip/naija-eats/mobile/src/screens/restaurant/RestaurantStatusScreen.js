import React, { useCallback, useState } from 'react';
import { View, Text, StyleSheet, FlatList, RefreshControl, TouchableOpacity } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import client from '../../api/client';
import { useAuth } from '../../context/AuthContext';

const STATUS_COPY = {
  pending_payment: { label: 'Awaiting payment', color: '#C77700' },
  paid: { label: 'Fee paid — pending admin review', color: '#0B6FC7' },
  approved: { label: 'Approved & live', color: '#0B8457' },
  rejected: { label: 'Rejected', color: '#C71C1C' },
};

export default function RestaurantStatusScreen({ navigation }) {
  const { logout } = useAuth();
  const [restaurants, setRestaurants] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await client.get('/restaurants/mine/status');
      setRestaurants(data);
    } catch (err) {
      console.warn(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  return (
    <View style={styles.container}>
      <View style={styles.headerRow}>
        <Text style={styles.title}>Your Restaurants</Text>
        <TouchableOpacity onPress={logout}>
          <Text style={styles.logout}>Log out</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.registerButton} onPress={() => navigation.navigate('Register')}>
        <Text style={styles.registerButtonText}>+ Register a new restaurant</Text>
      </TouchableOpacity>

      <FlatList
        data={restaurants}
        keyExtractor={(item) => item.id}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={load} />}
        ListEmptyComponent={
          !loading && <Text style={styles.empty}>You haven't registered a restaurant yet.</Text>
        }
        renderItem={({ item }) => {
          const status = STATUS_COPY[item.registration_status] || { label: item.registration_status, color: '#666' };
          return (
            <View style={styles.card}>
              <Text style={styles.name}>{item.name}</Text>
              <Text style={[styles.status, { color: status.color }]}>{status.label}</Text>
              {item.registration_status === 'approved' && (
                <Text style={styles.hint} onPress={() => navigation.navigate('Dashboard', { restaurant: item })}>
                  Go to dashboard →
                </Text>
              )}
            </View>
          );
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', padding: 16 },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  title: { fontSize: 22, fontWeight: '800' },
  logout: { color: '#C71C1C', fontSize: 13, fontWeight: '600' },
  registerButton: {
    borderWidth: 1,
    borderColor: '#0B8457',
    borderRadius: 10,
    padding: 14,
    alignItems: 'center',
    marginBottom: 20,
  },
  registerButtonText: { color: '#0B8457', fontWeight: '700' },
  empty: { textAlign: 'center', color: '#888', marginTop: 40 },
  card: { backgroundColor: '#F6F6F6', borderRadius: 12, padding: 16, marginBottom: 12 },
  name: { fontSize: 16, fontWeight: '700' },
  status: { fontSize: 13, fontWeight: '700', marginTop: 6 },
  hint: { fontSize: 13, color: '#0B8457', marginTop: 10, fontWeight: '600' },
});
