import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, Alert } from 'react-native';
import { WebView } from 'react-native-webview';
import client from '../../api/client';
import { formatNaira } from '../../utils/format';

export default function RegisterPaymentScreen({ route, navigation }) {
  const { restaurant } = route.params;
  const [authUrl, setAuthUrl] = useState(null);
  const [reference, setReference] = useState(null);
  const [verifying, setVerifying] = useState(false);

  useEffect(() => {
    client
      .post('/payments/registration/initiate', { restaurantId: restaurant.id })
      .then(({ data }) => {
        setAuthUrl(data.authorizationUrl);
        setReference(data.reference);
      })
      .catch((err) => {
        Alert.alert('Could not start payment', err.response?.data?.error || 'Try again later');
        navigation.goBack();
      });
  }, [restaurant.id]);

  // Paystack redirects to our callback_url once the user finishes on their hosted checkout page.
  // We intercept that navigation, then call our own /verify endpoint to confirm server-side.
  async function handleNavStateChange(navState) {
    if (navState.url.includes('/payments/registration/callback') && reference && !verifying) {
      setVerifying(true);
      try {
        const { data } = await client.get(`/payments/registration/verify/${reference}`);
        if (data.success) {
          Alert.alert(
            'Payment received!',
            'Your registration fee has been paid. Your restaurant is now pending admin approval.',
            [{ text: 'OK', onPress: () => navigation.navigate('RestaurantStatus') }]
          );
        } else {
          Alert.alert('Payment not confirmed', 'If money left your account, contact support with your reference: ' + reference);
        }
      } catch (err) {
        Alert.alert('Could not verify payment', 'Please check your registration status shortly.');
      } finally {
        setVerifying(false);
      }
    }
  }

  if (!authUrl) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#0B8457" />
        <Text style={styles.loadingText}>Preparing secure payment…</Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1 }}>
      <View style={styles.banner}>
        <Text style={styles.bannerText}>
          Registration fee: {formatNaira(restaurant.registration_fee_kobo)}
        </Text>
      </View>
      <WebView source={{ uri: authUrl }} onNavigationStateChange={handleNavStateChange} startInLoadingState />
      {verifying && (
        <View style={styles.overlay}>
          <ActivityIndicator size="large" color="#fff" />
          <Text style={styles.overlayText}>Confirming payment…</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  loadingText: { marginTop: 12, color: '#666' },
  banner: { backgroundColor: '#0B8457', padding: 12, alignItems: 'center' },
  bannerText: { color: '#fff', fontWeight: '700' },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.6)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  overlayText: { color: '#fff', marginTop: 12, fontWeight: '600' },
});
