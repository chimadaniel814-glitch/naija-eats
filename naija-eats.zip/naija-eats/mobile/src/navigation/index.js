import React from 'react';
import { View, ActivityIndicator } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import { useAuth } from '../context/AuthContext';

import LoginScreen from '../screens/auth/LoginScreen';
import SignupScreen from '../screens/auth/SignupScreen';

import HomeScreen from '../screens/customer/HomeScreen';
import RestaurantScreen from '../screens/customer/RestaurantScreen';
import CartScreen from '../screens/customer/CartScreen';
import CheckoutScreen from '../screens/customer/CheckoutScreen';
import OrdersScreen from '../screens/customer/OrdersScreen';

import RegisterScreen from '../screens/restaurant/RegisterScreen';
import RegisterPaymentScreen from '../screens/restaurant/RegisterPaymentScreen';
import RestaurantStatusScreen from '../screens/restaurant/RestaurantStatusScreen';
import DashboardScreen from '../screens/restaurant/DashboardScreen';

const AuthStack = createNativeStackNavigator();
const CustomerTabs = createBottomTabNavigator();
const CustomerStack = createNativeStackNavigator();
const RestaurantStack = createNativeStackNavigator();

function AuthNavigator() {
  return (
    <AuthStack.Navigator screenOptions={{ headerShown: false }}>
      <AuthStack.Screen name="Login" component={LoginScreen} />
      <AuthStack.Screen name="Signup" component={SignupScreen} />
    </AuthStack.Navigator>
  );
}

// Customer: browsing/ordering lives in a stack, with a simple tab bar for Home vs Orders
function CustomerHomeStack() {
  return (
    <CustomerStack.Navigator>
      <CustomerStack.Screen name="Restaurants" component={HomeScreen} options={{ title: 'Naija Eats' }} />
      <CustomerStack.Screen name="Restaurant" component={RestaurantScreen} options={{ title: '' }} />
      <CustomerStack.Screen name="Cart" component={CartScreen} />
      <CustomerStack.Screen name="Checkout" component={CheckoutScreen} />
    </CustomerStack.Navigator>
  );
}

function CustomerNavigator() {
  return (
    <CustomerTabs.Navigator screenOptions={{ headerShown: false }}>
      <CustomerTabs.Screen name="Browse" component={CustomerHomeStack} />
      <CustomerTabs.Screen name="Orders" component={OrdersScreen} options={{ headerShown: true }} />
    </CustomerTabs.Navigator>
  );
}

// Restaurant owner: registration → payment → status → dashboard
function RestaurantNavigator() {
  return (
    <RestaurantStack.Navigator>
      <RestaurantStack.Screen name="RestaurantStatus" component={RestaurantStatusScreen} options={{ title: 'My Restaurant' }} />
      <RestaurantStack.Screen name="Register" component={RegisterScreen} options={{ title: 'Register Restaurant' }} />
      <RestaurantStack.Screen name="RegisterPayment" component={RegisterPaymentScreen} options={{ title: 'Pay Registration Fee' }} />
      <RestaurantStack.Screen name="Dashboard" component={DashboardScreen} options={{ title: 'Orders' }} />
    </RestaurantStack.Navigator>
  );
}

export default function RootNavigator() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator size="large" color="#0B8457" />
      </View>
    );
  }

  return (
    <NavigationContainer>
      {!user ? (
        <AuthNavigator />
      ) : user.role === 'restaurant_owner' ? (
        <RestaurantNavigator />
      ) : (
        <CustomerNavigator />
      )}
    </NavigationContainer>
  );
}
