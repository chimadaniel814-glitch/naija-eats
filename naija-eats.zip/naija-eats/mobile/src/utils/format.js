// All prices are stored/transmitted in kobo (1 naira = 100 kobo), Paystack's native unit.
export function formatNaira(kobo) {
  const naira = kobo / 100;
  return `₦${naira.toLocaleString('en-NG', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
}
