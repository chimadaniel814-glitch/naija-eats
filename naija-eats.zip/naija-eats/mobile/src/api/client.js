import axios from 'axios';
import * as SecureStore from 'expo-secure-store';

// Point this at your deployed backend, or your machine's LAN IP while testing
// on a physical phone with Expo Go (e.g. http://192.168.1.50:4000).
export const API_BASE_URL = 'http://localhost:4000/api';

const client = axios.create({ baseURL: API_BASE_URL });

client.interceptors.request.use(async (config) => {
  const token = await SecureStore.getItemAsync('authToken');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

export async function saveToken(token) {
  await SecureStore.setItemAsync('authToken', token);
}

export async function clearToken() {
  await SecureStore.deleteItemAsync('authToken');
}

export default client;
