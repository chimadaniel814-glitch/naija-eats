# Submitting Naija Eats to the App Store

This is the exact sequence to go from this codebase to a live App Store
listing, using EAS (Expo Application Services) — Expo's official build/submit
pipeline, which handles code signing so you don't need a Mac.

You must run these commands yourself — they need your Apple credentials,
which can't be entered or stored by anyone else on your behalf.

## Prerequisites (do these first)

1. **Apple Developer Program membership** — $99/year, enroll at
   https://developer.apple.com/programs/ (takes up to 48h for approval if new).
2. **Expo account** — free, sign up at https://expo.dev.
3. **A real backend URL** — the app currently points at `http://localhost:4000`
   for local testing. Before building for the App Store, deploy the `backend`
   folder somewhere reachable over **HTTPS** (Railway, Render, Fly.io, a VPS —
   anywhere that gives you a `https://...` domain), then update
   `mobile/src/api/client.js`:
   ```js
   export const API_BASE_URL = 'https://your-real-domain.com/api';
   ```
   Apple will reject (or the app will simply fail to load data) if it's still
   pointed at localhost or plain `http://`.
4. **Live Paystack keys** — swap the backend's `.env` from `sk_test_...` /
   `pk_test_...` to your live `sk_live_...` / `pk_live_...` keys once you're
   ready to charge real registration fees.
5. **A hosted privacy policy URL** — see `PRIVACY_POLICY.md` in this folder.

## 1. Install the EAS CLI and log in

```bash
cd mobile
npm install -g eas-cli
eas login
```

## 2. Link this project to your Expo account

```bash
eas init
```
This creates a project on expo.dev and writes a real `projectId` into
`app.json`, replacing the `YOUR_EAS_PROJECT_ID` placeholder I left there.

## 3. Configure iOS credentials

```bash
eas build:configure
```
Choose iOS. EAS will offer to **generate and manage your signing
certificates and provisioning profile automatically** — recommended, unless
you already manage these yourself in Apple Developer's portal.

## 4. Do a preview build first (strongly recommended)

Build an installable version to test on a real device before submitting:
```bash
eas build --platform ios --profile preview
```
EAS gives you a link to install it on a registered test device, or use
TestFlight internal testing (see step 6) — actually verify login, ordering,
and the Paystack payment flow work end-to-end against your real backend
before submitting for review.

## 5. Production build

```bash
eas build --platform ios --profile production
```
This produces the signed `.ipa` file, built on Expo's servers — takes roughly
10–20 minutes. `eas.json` already has an `autoIncrement` setting so the build
number bumps automatically each time.

## 6. Submit to App Store Connect

```bash
eas submit --platform ios --profile production
```
You'll be prompted for (or can pre-fill in `eas.json`):
- Your Apple ID email
- Your Apple Team ID (found at https://developer.apple.com/account under Membership)
- Your App Store Connect App ID (create the app listing first at
  https://appstoreconnect.apple.com → My Apps → "+" → New App, using bundle
  identifier `com.naijaeats.app` — this generates the ASC App ID you need here)

This uploads the build to App Store Connect and attaches it to TestFlight.

## 7. Fill in the App Store listing

In App Store Connect, on your app's page:
- Paste in the content from `APP_STORE_LISTING.md` (name, description,
  keywords, support URL, privacy policy URL, category).
- Upload screenshots (see the list in that file for which screens to capture).
- Under **App Review Information**, add the demo account credentials and
  review notes from `APP_STORE_LISTING.md` — reviewers cannot get past
  login without a working account, and this app requires one.
- Select the build you just uploaded via `eas submit`, under **Build**.

## 8. Submit for review

Click **"Add for Review"** → **"Submit to App Review"**. Typical review time
is 24–48 hours. Respond promptly if Apple's review team messages you —
delayed replies restart the review clock.

## Things likely to trigger a rejection or delay, specific to this app

- **Broken demo login** — the single most common rejection. Pre-seed the
  demo restaurant-owner account with an *already-approved* restaurant, since
  reviewers won't be able to complete a live Paystack payment or wait for
  your manual admin approval step.
- **Payment for a real-world service, not digital content** — Apple requires
  Apple's In-App Purchase for digital goods/content, but allows external
  payment processors (like Paystack here) for real-world services — which is
  what the restaurant registration fee is. This is generally fine, but is a
  judgment call reviewers sometimes push back on; the review notes template
  above states this explicitly to preempt that. I'm not a lawyer — if you
  want certainty, Apple's own guideline is section 3.1.1/3.1.3 of the App
  Store Review Guidelines, worth a read before submitting.
- **Placeholder icons** — I generated simple placeholder icons
  (`assets/icon.png`, `assets/adaptive-icon.png`, `assets/splash-icon.png`).
  These will pass technical validation but you'll likely want real branded
  artwork before a public launch.
- **`localhost` API calls** — must be fixed per step 4 above before building,
  or every screen will simply fail to load data for the reviewer.

## Android (Google Play), if you want it too

The same EAS pipeline builds Android:
```bash
eas build --platform android --profile production
eas submit --platform android --profile production
```
Google Play review is typically faster (hours, not days) and needs a
Google Play Console developer account ($25 one-time) instead of Apple's.
Happy to write up the equivalent Play Store checklist if you want it.
