const express = require('express');
const { body, validationResult } = require('express-validator');
const db = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();

// GET /api/restaurants - public list of approved, active restaurants
// Query params: city, cuisine
router.get('/', async (req, res) => {
  const { city, cuisine } = req.query;
  let query = `SELECT id, name, description, cuisine_type, address, city, state, logo_url
               FROM restaurants WHERE is_active = true`;
  const params = [];

  if (city) {
    params.push(city);
    query += ` AND city ILIKE $${params.length}`;
  }
  if (cuisine) {
    params.push(`%${cuisine}%`);
    query += ` AND cuisine_type ILIKE $${params.length}`;
  }
  query += ' ORDER BY created_at DESC';

  try {
    const result = await db.query(query, params);
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not fetch restaurants' });
  }
});

// GET /api/restaurants/:id - public detail
router.get('/:id', async (req, res) => {
  try {
    const result = await db.query(
      `SELECT id, name, description, cuisine_type, address, city, state, phone, logo_url
       FROM restaurants WHERE id = $1 AND is_active = true`,
      [req.params.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Restaurant not found' });
    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not fetch restaurant' });
  }
});

// POST /api/restaurants/register
// Step 1 of onboarding: restaurant_owner submits business details.
// Creates a restaurant row with registration_status = pending_payment.
// Frontend then calls /api/payments/registration/initiate to pay the fee.
router.post(
  '/register',
  requireAuth,
  requireRole('restaurant_owner'),
  [
    body('name').notEmpty(),
    body('address').notEmpty(),
    body('city').notEmpty(),
    body('state').notEmpty(),
    body('phone').notEmpty(),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const { name, description, cuisineType, address, city, state, phone, logoUrl } = req.body;
    const feeKobo = parseInt(process.env.RESTAURANT_REGISTRATION_FEE_KOBO || '1000000', 10);

    try {
      const result = await db.query(
        `INSERT INTO restaurants
          (owner_id, name, description, cuisine_type, address, city, state, phone, logo_url, registration_fee_kobo)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
         RETURNING *`,
        [req.user.id, name, description, cuisineType, address, city, state, phone, logoUrl, feeKobo]
      );
      res.status(201).json(result.rows[0]);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Registration failed' });
    }
  }
);

// GET /api/restaurants/mine/status - restaurant owner checks their own restaurant(s)
router.get('/mine/status', requireAuth, requireRole('restaurant_owner'), async (req, res) => {
  try {
    const result = await db.query(
      `SELECT id, name, registration_status, registration_paid_at, is_active
       FROM restaurants WHERE owner_id = $1 ORDER BY created_at DESC`,
      [req.user.id]
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not fetch status' });
  }
});

// PATCH /api/restaurants/:id/approve - admin approves a restaurant after fee is paid
router.patch('/:id/approve', requireAuth, requireRole('admin'), async (req, res) => {
  try {
    const result = await db.query(
      `UPDATE restaurants SET registration_status = 'approved', is_active = true
       WHERE id = $1 AND registration_status = 'paid'
       RETURNING *`,
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(400).json({ error: 'Restaurant not eligible for approval (fee not paid yet)' });
    }
    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Approval failed' });
  }
});

module.exports = router;
