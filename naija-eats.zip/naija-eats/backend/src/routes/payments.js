const express = require('express');
const axios = require('axios');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');
const db = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();

const paystack = axios.create({
  baseURL: 'https://api.paystack.co',
  headers: { Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}` },
});

// POST /api/payments/registration/initiate
// body: { restaurantId }
// Starts a Paystack transaction for the restaurant's registration fee.
router.post('/registration/initiate', requireAuth, requireRole('restaurant_owner'), async (req, res) => {
  const { restaurantId } = req.body;
  try {
    const restResult = await db.query(
      `SELECT * FROM restaurants WHERE id = $1 AND owner_id = $2`,
      [restaurantId, req.user.id]
    );
    const restaurant = restResult.rows[0];
    if (!restaurant) return res.status(404).json({ error: 'Restaurant not found' });
    if (restaurant.registration_status === 'approved') {
      return res.status(400).json({ error: 'Restaurant already approved' });
    }

    const reference = `regfee_${uuidv4()}`;

    const paystackResp = await paystack.post('/transaction/initialize', {
      email: req.user.email,
      amount: restaurant.registration_fee_kobo, // Paystack amount is in kobo
      reference,
      callback_url: `${process.env.APP_BASE_URL}/api/payments/registration/callback`,
      metadata: { restaurantId, purpose: 'restaurant_registration_fee' },
    });

    await db.query(
      `INSERT INTO registration_payments (restaurant_id, reference, amount_kobo, status)
       VALUES ($1,$2,$3,'initiated')`,
      [restaurantId, reference, restaurant.registration_fee_kobo]
    );

    // authorization_url is what the Expo app opens in a WebView/browser for the user to pay
    res.json({
      authorizationUrl: paystackResp.data.data.authorization_url,
      accessCode: paystackResp.data.data.access_code,
      reference,
    });
  } catch (err) {
    console.error(err.response?.data || err.message);
    res.status(500).json({ error: 'Could not initiate payment' });
  }
});

// GET /api/payments/registration/verify/:reference
// Called by the mobile app after the WebView redirects back, to confirm payment succeeded.
router.get('/registration/verify/:reference', requireAuth, async (req, res) => {
  const { reference } = req.params;
  try {
    const verifyResp = await paystack.get(`/transaction/verify/${reference}`);
    const data = verifyResp.data.data;
    const success = data.status === 'success';

    const payRow = await db.query(
      `UPDATE registration_payments SET status = $1, paystack_response = $2 WHERE reference = $3 RETURNING *`,
      [success ? 'success' : 'failed', JSON.stringify(data), reference]
    );
    if (payRow.rows.length === 0) return res.status(404).json({ error: 'Payment record not found' });

    if (success) {
      await db.query(
        `UPDATE restaurants SET registration_status = 'paid', registration_paid_at = now()
         WHERE id = $1`,
        [payRow.rows[0].restaurant_id]
      );
    }

    res.json({ success, status: data.status });
  } catch (err) {
    console.error(err.response?.data || err.message);
    res.status(500).json({ error: 'Could not verify payment' });
  }
});

// POST /api/payments/webhook - Paystack server-to-server webhook (recommended over relying on client verify alone)
// Configure this URL in your Paystack dashboard. Raw body must be used for signature check;
// wire this route with express.raw({type: 'application/json'}) before json() middleware in server.js if you enable it.
router.post('/webhook', async (req, res) => {
  const signature = req.headers['x-paystack-signature'];
  const hash = crypto
    .createHmac('sha512', process.env.PAYSTACK_SECRET_KEY)
    .update(JSON.stringify(req.body))
    .digest('hex');

  if (hash !== signature) return res.sendStatus(401);

  const event = req.body;
  if (event.event === 'charge.success') {
    const reference = event.data.reference;
    const payRow = await db.query(
      `UPDATE registration_payments SET status = 'success', paystack_response = $1 WHERE reference = $2 RETURNING *`,
      [JSON.stringify(event.data), reference]
    );
    if (payRow.rows.length > 0) {
      await db.query(
        `UPDATE restaurants SET registration_status = 'paid', registration_paid_at = now() WHERE id = $1`,
        [payRow.rows[0].restaurant_id]
      );
    }
  }
  res.sendStatus(200);
});

module.exports = router;
