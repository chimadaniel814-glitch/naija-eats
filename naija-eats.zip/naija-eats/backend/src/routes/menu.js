const express = require('express');
const { body, validationResult } = require('express-validator');
const db = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();

// GET /api/menu/restaurant/:restaurantId - public
router.get('/restaurant/:restaurantId', async (req, res) => {
  try {
    const result = await db.query(
      `SELECT * FROM menu_items WHERE restaurant_id = $1 AND is_available = true ORDER BY category, name`,
      [req.params.restaurantId]
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not fetch menu' });
  }
});

// POST /api/menu - restaurant owner adds an item to their own restaurant
router.post(
  '/',
  requireAuth,
  requireRole('restaurant_owner'),
  [
    body('restaurantId').isUUID(),
    body('name').notEmpty(),
    body('priceKobo').isInt({ min: 1 }),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const { restaurantId, name, description, priceKobo, category, imageUrl } = req.body;

    try {
      // Confirm ownership + that the restaurant is approved before allowing menu edits
      const owns = await db.query(
        `SELECT id, registration_status FROM restaurants WHERE id = $1 AND owner_id = $2`,
        [restaurantId, req.user.id]
      );
      if (owns.rows.length === 0) return res.status(403).json({ error: 'Not your restaurant' });
      if (owns.rows[0].registration_status !== 'approved') {
        return res.status(403).json({ error: 'Restaurant must be approved before adding menu items' });
      }

      const result = await db.query(
        `INSERT INTO menu_items (restaurant_id, name, description, price_kobo, category, image_url)
         VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
        [restaurantId, name, description, priceKobo, category, imageUrl]
      );
      res.status(201).json(result.rows[0]);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Could not add menu item' });
    }
  }
);

module.exports = router;
