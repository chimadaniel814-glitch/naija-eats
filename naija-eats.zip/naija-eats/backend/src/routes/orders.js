const express = require('express');
const { body, validationResult } = require('express-validator');
const db = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();

// POST /api/orders - customer places an order
// body: { restaurantId, deliveryAddress, items: [{ menuItemId, quantity }], deliveryFeeKobo }
router.post(
  '/',
  requireAuth,
  requireRole('customer'),
  [
    body('restaurantId').isUUID(),
    body('deliveryAddress').notEmpty(),
    body('items').isArray({ min: 1 }),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const { restaurantId, deliveryAddress, items, deliveryFeeKobo = 0 } = req.body;
    const client = await db.pool.connect();

    try {
      await client.query('BEGIN');

      // Price items server-side from current menu, never trust client prices
      const ids = items.map((i) => i.menuItemId);
      const menuResult = await client.query(
        `SELECT id, name, price_kobo FROM menu_items WHERE id = ANY($1::uuid[]) AND restaurant_id = $2`,
        [ids, restaurantId]
      );
      const menuById = Object.fromEntries(menuResult.rows.map((r) => [r.id, r]));

      let subtotal = 0;
      const lineItems = items.map((i) => {
        const menuItem = menuById[i.menuItemId];
        if (!menuItem) throw new Error(`Menu item ${i.menuItemId} not found on this restaurant`);
        const qty = Math.max(1, parseInt(i.quantity, 10) || 1);
        subtotal += menuItem.price_kobo * qty;
        return { menuItemId: menuItem.id, name: menuItem.name, price: menuItem.price_kobo, qty };
      });

      const total = subtotal + deliveryFeeKobo;

      const orderResult = await client.query(
        `INSERT INTO orders (customer_id, restaurant_id, delivery_address, subtotal_kobo, delivery_fee_kobo, total_kobo)
         VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
        [req.user.id, restaurantId, deliveryAddress, subtotal, deliveryFeeKobo, total]
      );
      const order = orderResult.rows[0];

      for (const li of lineItems) {
        await client.query(
          `INSERT INTO order_items (order_id, menu_item_id, name_snapshot, price_kobo_snapshot, quantity)
           VALUES ($1,$2,$3,$4,$5)`,
          [order.id, li.menuItemId, li.name, li.price, li.qty]
        );
      }

      await client.query('COMMIT');
      res.status(201).json({ ...order, items: lineItems });
    } catch (err) {
      await client.query('ROLLBACK');
      console.error(err);
      res.status(400).json({ error: err.message || 'Could not place order' });
    } finally {
      client.release();
    }
  }
);

// GET /api/orders/mine - customer's own orders
router.get('/mine', requireAuth, requireRole('customer'), async (req, res) => {
  const result = await db.query(
    `SELECT o.*, r.name AS restaurant_name FROM orders o
     JOIN restaurants r ON r.id = o.restaurant_id
     WHERE o.customer_id = $1 ORDER BY o.created_at DESC`,
    [req.user.id]
  );
  res.json(result.rows);
});

// GET /api/orders/restaurant/:restaurantId - restaurant owner's incoming orders
router.get('/restaurant/:restaurantId', requireAuth, requireRole('restaurant_owner'), async (req, res) => {
  const owns = await db.query(`SELECT id FROM restaurants WHERE id = $1 AND owner_id = $2`, [
    req.params.restaurantId,
    req.user.id,
  ]);
  if (owns.rows.length === 0) return res.status(403).json({ error: 'Not your restaurant' });

  const result = await db.query(
    `SELECT * FROM orders WHERE restaurant_id = $1 ORDER BY created_at DESC`,
    [req.params.restaurantId]
  );
  res.json(result.rows);
});

// PATCH /api/orders/:id/status - restaurant owner updates order status
router.patch(
  '/:id/status',
  requireAuth,
  requireRole('restaurant_owner'),
  [body('status').isIn(['accepted', 'preparing', 'out_for_delivery', 'delivered', 'cancelled'])],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const result = await db.query(
      `UPDATE orders SET status = $1
       WHERE id = $2 AND restaurant_id IN (SELECT id FROM restaurants WHERE owner_id = $3)
       RETURNING *`,
      [req.body.status, req.params.id, req.user.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Order not found' });
    res.json(result.rows[0]);
  }
);

module.exports = router;
