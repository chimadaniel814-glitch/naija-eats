const { Pool } = require('pg');
require('dotenv').config();

// Hosted Postgres (Railway, Render, Supabase, etc.) requires SSL in production;
// local development typically doesn't have a cert configured, so only enable it
// when NODE_ENV=production. Most managed Postgres providers use certs that
// Node won't validate by default, hence rejectUnauthorized: false — this still
// encrypts the connection, it just skips CA validation (standard practice for
// these platforms; see your provider's docs if they recommend otherwise).
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
});

module.exports = {
  query: (text, params) => pool.query(text, params),
  pool,
};
