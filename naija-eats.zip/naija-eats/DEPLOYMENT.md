# Deploying the Naija Eats Backend

The mobile app currently points at `http://localhost:4000`, which only works
on your own machine. To let real users (or Apple's App Review team) use the
app, the backend needs to run somewhere with a public HTTPS URL, 24/7.

## Picking a host

| | **Railway** (recommended) | **Render** | **Fly.io** | **DigitalOcean/Linode VPS** |
|---|---|---|---|---|
| Setup effort | Lowest — one dashboard for app + Postgres | Low — similar, separate Postgres add-on | Medium — CLI-driven | Highest — you manage the OS |
| Free/starter cost | ~$5/mo credit free, then usage-based (~$5–10/mo typical for this app) | Free web service tier (spins down when idle, causing slow first request) + free 90-day Postgres, then paid | Free allowance covers small apps | From ~$4–6/mo, but no managed Postgres — you'd run it yourself |
| Postgres included | Yes, one click | Yes, separate resource | Yes, via `fly postgres` | No — self-managed |
| Good fit here | Best default: cheapest path to "just works" with zero server admin | Fine alternative, but free tier's cold-start delay hurts UX for a live food ordering app | Fine if you're already comfortable with its CLI | Only if you specifically want full server control |

**Recommendation: Railway.** It's the least setup for a Node + Postgres app
like this one, and I've already added `railway.json` and a production-ready
`db.js` (SSL-aware) and `migrate.js` script to the backend for it. The steps
below are for Railway; Render is a close second if you'd rather use it — same
general flow, different dashboard.

## Step-by-step: Railway

1. **Push this code to a GitHub repo** (Railway deploys from GitHub, or you
   can use the Railway CLI to deploy straight from your folder — GitHub is
   easier to keep updating later):
   ```bash
   cd naija-eats
   git init
   git add .
   git commit -m "Initial commit"
   ```
   Create a new repo on GitHub, then:
   ```bash
   git remote add origin https://github.com/YOUR_USERNAME/naija-eats.git
   git push -u origin main
   ```

2. **Create a Railway account** at https://railway.app (GitHub login is easiest).

3. **New Project → Deploy from GitHub repo** → select your `naija-eats` repo.
   When it asks for the root directory / working directory, set it to
   `backend` (this repo has both `backend` and `mobile` at the top level).

4. **Add a Postgres database**: in the same project, click **+ New** →
   **Database** → **PostgreSQL**. Railway provisions it and automatically
   creates a `DATABASE_URL` variable.

5. **Link the database URL to your backend service**: in your backend
   service's **Variables** tab, add a reference to the Postgres service's
   `DATABASE_URL` (Railway lets you reference another service's variable
   directly — click "Add Variable Reference"). If it doesn't offer that,
   just copy the value from the Postgres service's Variables tab and paste
   it in as `DATABASE_URL`.

6. **Set the rest of the environment variables** on the backend service
   (Variables tab), matching `backend/.env.example`:
   ```
   NODE_ENV=production
   JWT_SECRET=<generate a long random string>
   PAYSTACK_SECRET_KEY=sk_live_... (or sk_test_... while still testing)
   PAYSTACK_PUBLIC_KEY=pk_live_... (or pk_test_...)
   RESTAURANT_REGISTRATION_FEE_KOBO=1000000
   APP_BASE_URL=<filled in after step 7, once you have your Railway URL>
   ```
   `PORT` doesn't need to be set — Railway injects it automatically and
   `server.js` already reads `process.env.PORT`.

7. **Deploy.** Railway builds and starts the service automatically on push.
   Once it's live, go to **Settings → Networking → Generate Domain** to get
   your public URL, something like `https://naija-eats-backend.up.railway.app`.
   Go back to step 6 and set `APP_BASE_URL` to that URL, then redeploy
   (Railway does this automatically when you save a variable).

8. **Run the database migration** — the schema needs to be created once
   against the live database. Easiest from your own machine:
   ```bash
   cd backend
   DATABASE_URL="<paste the Postgres DATABASE_URL from Railway's Variables tab>" NODE_ENV=production npm run migrate
   ```

9. **Verify it's live**:
   ```bash
   curl https://naija-eats-backend.up.railway.app/health
   ```
   should return `{"status":"ok"}`.

10. **Point the mobile app at it.** In `mobile/src/api/client.js`:
    ```js
    export const API_BASE_URL = 'https://naija-eats-backend.up.railway.app/api';
    ```

11. **Update your Paystack dashboard** (Settings → API Keys & Webhooks) to
    point the webhook URL at
    `https://naija-eats-backend.up.railway.app/api/payments/webhook`, so
    payments are confirmed reliably even if a user closes the app mid-payment
    (the in-app verify call in `RegisterPaymentScreen` handles the common
    case, but the webhook is the safety net for production).

## Creating your first admin user

There's no signup flow for `role: admin` in the app (by design — anyone
could otherwise self-approve their own restaurant). After deploying, create
one manually:

```bash
# from the backend folder, with DATABASE_URL pointed at your live database
node -e "
require('dotenv').config();
const bcrypt = require('bcryptjs');
const db = require('./src/db');
(async () => {
  const hash = await bcrypt.hash('CHANGE_ME_STRONG_PASSWORD', 10);
  await db.query(
    \`INSERT INTO users (full_name, email, phone, password_hash, role)
     VALUES ('Admin', 'admin@naijaeats.app', '08000000000', \$1, 'admin')\`,
    [hash]
  );
  console.log('Admin created');
  process.exit(0);
})();
"
```
Then log in as that user via `POST /api/auth/login` (e.g. with `curl` or
Postman) to get a token, and use it to call
`PATCH /api/restaurants/:id/approve` for restaurants that have paid.

## What changed in the codebase for this

- `backend/src/db.js` — now enables SSL when `NODE_ENV=production`, which
  Railway/Render/most managed Postgres require.
- `backend/src/migrate.js` — new: runs `schema.sql` against whatever
  `DATABASE_URL` is set, so you don't need `psql` installed locally.
- `backend/railway.json` — tells Railway how to health-check and restart
  the service.
- `backend/package.json` — added an `engines` field pinning Node ≥18.

## Next

Once this is live and `API_BASE_URL` is updated, you're unblocked on the App
Store submission steps in `APP_STORE_SUBMISSION.md` (steps 3–4 there
specifically needed this). Let me know when it's deployed and I'll help you
smoke-test the full signup → registration → payment → approval flow against
the real URL before you build.
